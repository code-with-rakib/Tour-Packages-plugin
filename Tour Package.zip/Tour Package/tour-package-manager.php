<?php
/**
 * Plugin Name: Tour Package 
 * Plugin URI: https://yourwebsite.com
 * Description: [tour_packages] The Tour Package Plugin is a powerful and user-friendly solution designed for travel agencies, tour operators, and booking websites. It allows you to create, manage, and sell customized tour packages effortlessly. With a seamless booking system, payment integration, and an intuitive dashboard, this plugin ensures a hassle-free experience for both administrators and customers..
 * Version: 1.0
 * Author: Rakib Hasan
 * Author URI: https://codewithrakib.com
 * License: GPL2
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Enqueue CSS
function tour_package_enqueue_styles() {
    wp_enqueue_style('tour-package-style', plugin_dir_url(__FILE__) . 'assets/css/style.css');
}
add_action('wp_enqueue_scripts', 'tour_package_enqueue_styles');

// Register Custom Post Type for Tour Packages
function tour_package_cpt() {
    $labels = array(
        'name' => 'Tour Packages',
        'singular_name' => 'Tour Package',
        'menu_name' => 'Tour Packages',
        'name_admin_bar' => 'Tour Package',
    );

    $args = array(
        'labels'        => $labels,
        'public'        => true,
        'menu_icon'     => 'dashicons-airplane',
        'supports'      => array('title', 'editor', 'thumbnail'),
        'has_archive'   => true,
        'rewrite'       => array('slug' => 'tour-packages'),
    );

    register_post_type('tour_package', $args);
}
add_action('init', 'tour_package_cpt');

// Add custom fields for Price, Duration, Location, and Optional Button
function tour_package_meta_boxes() {
    add_meta_box('tour_package_details', 'Tour Package Details', 'tour_package_meta_box_callback', 'tour_package', 'normal', 'high');
}
add_action('add_meta_boxes', 'tour_package_meta_boxes');

function tour_package_meta_box_callback($post) {
    $price = get_post_meta($post->ID, 'tour_price', true);
    $duration = get_post_meta($post->ID, 'tour_duration', true);
    $location = get_post_meta($post->ID, 'tour_location', true);
    $button_text = get_post_meta($post->ID, 'tour_button_text', true);
    $button_url = get_post_meta($post->ID, 'tour_button_url', true);
    ?>
    <label for="tour_price">Price:</label>
    <input type="text" id="tour_price" name="tour_price" value="<?php echo esc_attr($price); ?>" style="width: 100%;" /><br><br>
    
    <label for="tour_duration">Duration:</label>
    <input  type="text" id="tour_duration" name="tour_duration" ><?php echo esc_textarea($duration); ?><br><br>
    
    <label for="tour_location">Location:</label>
    <input type="text" id="tour_location" name="tour_location" value="<?php echo esc_attr($location); ?>" style="width: 100%;" /><br><br>
    
    <label for="tour_button_text">Button Text :</label>
    <input type="text" id="tour_button_text" name="tour_button_text" value="<?php echo esc_attr($button_text); ?>" style="width: 100%;" /><br><br>
    
    <label for="tour_button_url">Button URL :</label>
    <input type="text" id="tour_button_url" name="tour_button_url" value="<?php echo esc_attr($button_url); ?>" style="width: 100%;" />
    <?php
}

function save_tour_package_meta($post_id) {
    if (array_key_exists('tour_price', $_POST)) {
        update_post_meta($post_id, 'tour_price', sanitize_text_field($_POST['tour_price']));
    }
    if (array_key_exists('tour_duration', $_POST)) {
        update_post_meta($post_id, 'tour_duration', sanitize_text_field($_POST['tour_duration']));
    }
    if (array_key_exists('tour_location', $_POST)) {
        update_post_meta($post_id, 'tour_location', sanitize_text_field($_POST['tour_location']));
    }
    if (array_key_exists('tour_button_text', $_POST)) {
        update_post_meta($post_id, 'tour_button_text', sanitize_text_field($_POST['tour_button_text']));
    }
    if (array_key_exists('tour_button_url', $_POST)) {
        update_post_meta($post_id, 'tour_button_url', esc_url($_POST['tour_button_url']));
    }
}
add_action('save_post', 'save_tour_package_meta');

// Display Custom Columns in Admin Panel
function manage_tour_package_posts_columns($columns) {
    $columns['thumbnail'] = 'Image';
    $columns['price']     = 'Price';
    $columns['duration']  = 'Duration';
    $columns['location']  = 'Location';
    return $columns;
}
add_filter('manage_tour_package_posts_columns', 'manage_tour_package_posts_columns');

function custom_tour_package_column_content($column, $post_id) {
    switch ($column) {
        case 'thumbnail':
            if (has_post_thumbnail($post_id)) {
                echo get_the_post_thumbnail($post_id, array(50, 50));
            } else {
                echo 'No Image';
            }
            break;
        case 'price':
            echo get_post_meta($post_id, 'tour_price', true) ?: 'N/A';
            break;
        case 'duration':
            echo get_post_meta($post_id, 'tour_duration', true) ?: 'N/A';
            break;
        case 'location':
            echo get_post_meta($post_id, 'tour_location', true) ?: 'N/A';
            break;
    }
}
add_action('manage_tour_package_posts_custom_column', 'custom_tour_package_column_content', 10, 2);
// Change "Add New Post" to "Add Tour Package" in Admin Panel
function change_tour_package_title_text($title) {
    $screen = get_current_screen();
    if ('tour_package' == $screen->post_type) {
        $title = 'Enter Tour Package Title';
    }
    return $title;
}
add_filter('enter_title_here', 'change_tour_package_title_text');

// Change "Add New" text in Admin Menu
function change_tour_package_menu_text($menu) {
    global $submenu;
    if (isset($submenu['edit.php?post_type=tour_package'])) {
        $submenu['edit.php?post_type=tour_package'][10][0] = 'Add Tour Package';
    }
}
add_action('admin_menu', 'change_tour_package_menu_text');

/// Display Tour Packages Using Shortcode
function display_tour_packages() {
    $args = array(
        'post_type'      => 'tour_package',
        'posts_per_page' => -1,
    );

    $query = new WP_Query($args);
    $output = '<div class="tour-packages">';

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            $output .= '<div class="tour-package-item">';
            
            if (has_post_thumbnail()) {
                $output .= get_the_post_thumbnail(get_the_ID(), 'medium');
            }

            $output .= '<h2>' . get_the_title() . '</h2>';
            // Show full content without any limit
            $output .= '<p>' . get_the_content() . '</p>';
            
            $price = get_post_meta(get_the_ID(), 'tour_price', true);
            $duration = get_post_meta(get_the_ID(), 'tour_duration', true);
            $location = get_post_meta(get_the_ID(), 'tour_location', true);
            $button_text = get_post_meta(get_the_ID(), 'tour_button_text', true);
            $button_url = get_post_meta(get_the_ID(), 'tour_button_url', true);
            
            if (!empty($price)) {
                $output .= '<p><strong>Price:</strong> ' . esc_html($price) . '</p>';
            }
            if (!empty($duration)) {
                $output .= '<p><strong>Duration:</strong> ' . esc_html($duration) . '</p>';
            }
            if (!empty($location)) {
                $output .= '<p><strong>Location:</strong> ' . esc_html($location) . '</p>';
            }
            if (!empty($button_text) && !empty($button_url)) {
                $output .= '<p><a href="' . esc_url($button_url) . '" class="button" target="_blank">' . esc_html($button_text) . '</a></p>';
            }
            
            $output .= '</div>';
        }
        wp_reset_postdata();
    } else {
        $output .= '<p>No tour packages found.</p>';
    }
    $output .= '</div>';
    return $output;
}
add_shortcode('tour_packages', 'display_tour_packages');

?>
